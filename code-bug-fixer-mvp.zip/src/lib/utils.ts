import type { ErrorType } from "@/types/bug-report";

export function getErrorTypeColor(errorType: ErrorType): {
  bg: string;
  text: string;
  border: string;
  badge: string;
} {
  switch (errorType) {
    case "Syntax":
      return {
        bg: "bg-red-950/40",
        text: "text-red-400",
        border: "border-red-800/60",
        badge: "bg-red-900/60 text-red-300 border border-red-700/50",
      };
    case "Missing Definition":
      return {
        bg: "bg-amber-950/40",
        text: "text-amber-400",
        border: "border-amber-800/60",
        badge: "bg-amber-900/60 text-amber-300 border border-amber-700/50",
      };
    case "Crash Risk":
      return {
        bg: "bg-orange-950/40",
        text: "text-orange-400",
        border: "border-orange-800/60",
        badge: "bg-orange-900/60 text-orange-300 border border-orange-700/50",
      };
    case "Logic":
      return {
        bg: "bg-purple-950/40",
        text: "text-purple-400",
        border: "border-purple-800/60",
        badge: "bg-purple-900/60 text-purple-300 border border-purple-700/50",
      };
  }
}

export function getErrorTypeIcon(errorType: ErrorType): string {
  switch (errorType) {
    case "Syntax":
      return "⛔";
    case "Missing Definition":
      return "❓";
    case "Crash Risk":
      return "💥";
    case "Logic":
      return "🔄";
  }
}

export function formatLineLabel(line: number | string): string {
  if (typeof line === "number") return `Line ${line}`;
  return String(line);
}
