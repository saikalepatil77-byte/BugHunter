import type { LanguageOption } from "@/types/bug-report";

export const LANGUAGES: LanguageOption[] = [
  { value: "python",     label: "Python",      monacoId: "python",     icon: "🐍" },
  { value: "javascript", label: "JavaScript",  monacoId: "javascript", icon: "🟨" },
  { value: "typescript", label: "TypeScript",  monacoId: "typescript", icon: "🔷" },
  { value: "java",       label: "Java",        monacoId: "java",       icon: "☕" },
  { value: "cpp",        label: "C++",         monacoId: "cpp",        icon: "⚙️" },
  { value: "html",       label: "HTML",        monacoId: "html",       icon: "🌐" },
  { value: "css",        label: "CSS",         monacoId: "css",        icon: "🎨" },
  { value: "rust",       label: "Rust",        monacoId: "rust",       icon: "🦀" },
  { value: "go",         label: "Go",          monacoId: "go",         icon: "🐹" },
  { value: "php",        label: "PHP",         monacoId: "php",        icon: "🐘" },
];

export const DEFAULT_CODE_SAMPLES: Record<string, string> = {
  python: `# Paste your Python code here and click "Check for Bugs"
def calculate_average(numbers):
    total = 0
    for num in numbers:
        total += num
    return total / len(numbers)

result = calculate_average([10, 20, 30])
print("Average:", result)`,

  javascript: `// Paste your JavaScript code here and click "Check for Bugs"
function greetUser(name) {
  const greeting = "Hello, " + name + "!";
  console.log(greeting);
}

greetUser("World");`,

  typescript: `// Paste your TypeScript code here and click "Check for Bugs"
interface User {
  name: string;
  age: number;
}

function getUserInfo(user: User): string {
  return \`\${user.name} is \${user.age} years old.\`;
}`,

  java: `// Paste your Java code here and click "Check for Bugs"
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}`,

  cpp: `// Paste your C++ code here and click "Check for Bugs"
#include <iostream>
using namespace std;

int main() {
    cout << "Hello, World!" << endl;
    return 0;
}`,

  html: `<!-- Paste your HTML code here and click "Check for Bugs" -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Page</title>
</head>
<body>
    <h1>Hello, World!</h1>
</body>
</html>`,

  css: `/* Paste your CSS code here and click "Check for Bugs" */
body {
    margin: 0;
    padding: 0;
    font-family: sans-serif;
    background-color: #fff;
}`,

  rust: `// Paste your Rust code here and click "Check for Bugs"
fn main() {
    let message = "Hello, World!";
    println!("{}", message);
}`,

  go: `// Paste your Go code here and click "Check for Bugs"
package main

import "fmt"

func main() {
    fmt.Println("Hello, World!")
}`,

  php: `<?php
// Paste your PHP code here and click "Check for Bugs"
$message = "Hello, World!";
echo $message;
?>`,
};
