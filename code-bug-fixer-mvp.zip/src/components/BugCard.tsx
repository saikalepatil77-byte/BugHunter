"use client";

import { useState } from "react";
import { Copy, Check, ChevronDown, ChevronUp, MapPin } from "lucide-react";
import type { Bug } from "@/types/bug-report";
import { getErrorTypeColor, getErrorTypeIcon, formatLineLabel } from "@/lib/utils";

interface BugCardProps {
  bug: Bug;
  index: number;
}

export default function BugCard({ bug, index }: BugCardProps) {
  const [copied, setCopied] = useState(false);
  const [expanded, setExpanded] = useState(true);

  const colors = getErrorTypeColor(bug.errorType);
  const icon = getErrorTypeIcon(bug.errorType);

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(bug.suggestedFix);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback for environments without clipboard API
      const el = document.createElement("textarea");
      el.value = bug.suggestedFix;
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  }

  return (
    <div
      className={`rounded-xl border ${colors.border} ${colors.bg} overflow-hidden transition-all duration-200`}
    >
      {/* Card Header */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center gap-3 px-5 py-4 text-left hover:bg-white/5 transition-colors cursor-pointer"
      >
        {/* Bug number */}
        <span className="flex-shrink-0 w-7 h-7 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-bold text-slate-300">
          {index + 1}
        </span>

        {/* Error icon */}
        <span className="text-lg" role="img" aria-label={bug.errorType}>
          {icon}
        </span>

        {/* Line badge */}
        <div className="flex items-center gap-1.5">
          <MapPin className={`w-3.5 h-3.5 ${colors.text}`} />
          <span className={`text-xs font-semibold font-mono ${colors.text}`}>
            {formatLineLabel(bug.line)}
          </span>
        </div>

        {/* Error type badge */}
        <span className={`text-xs px-2.5 py-1 rounded-full font-semibold ${colors.badge}`}>
          {bug.errorType}
        </span>

        {/* Expand/collapse icon */}
        <span className="ml-auto text-slate-500">
          {expanded ? (
            <ChevronUp className="w-4 h-4" />
          ) : (
            <ChevronDown className="w-4 h-4" />
          )}
        </span>
      </button>

      {/* Card Body */}
      {expanded && (
        <div className="px-5 pb-5 space-y-4 border-t border-slate-800/60">
          {/* Explanation */}
          <div className="pt-4">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-widest mb-2">
              What&apos;s wrong
            </p>
            <p className="text-sm text-slate-300 leading-relaxed">{bug.explanation}</p>
          </div>

          {/* Suggested Fix */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-widest">
                Suggested fix
              </p>
              <button
                onClick={handleCopy}
                className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border font-medium transition-all duration-200 cursor-pointer ${
                  copied
                    ? "bg-emerald-900/50 border-emerald-700/50 text-emerald-300"
                    : "bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700 hover:text-white"
                }`}
                aria-label="Copy fix"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    Copy Fix
                  </>
                )}
              </button>
            </div>
            <div className="relative rounded-lg bg-slate-900/80 border border-slate-700/50 overflow-hidden">
              <div className="flex items-center gap-2 px-4 py-2 bg-slate-800/60 border-b border-slate-700/50">
                <div className="w-2.5 h-2.5 rounded-full bg-red-500/70" />
                <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/70" />
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/70" />
                <span className="ml-2 text-xs text-slate-500 font-mono">fix</span>
              </div>
              <pre className="px-4 py-3 text-sm font-mono text-emerald-300 overflow-x-auto leading-relaxed whitespace-pre-wrap break-words">
                <code>{bug.suggestedFix}</code>
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
