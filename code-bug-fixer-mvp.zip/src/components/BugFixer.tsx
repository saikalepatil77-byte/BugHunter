"use client";

import { useState, useCallback } from "react";
import dynamic from "next/dynamic";
import {
  Bug,
  Play,
  Trash2,
  ChevronDown,
  Loader2,
  Sparkles,
  GitBranch,
  Terminal,
} from "lucide-react";
import type { BugReport, Language } from "@/types/bug-report";
import type { CheckBugsResponse } from "@/types/bug-report";
import { LANGUAGES, DEFAULT_CODE_SAMPLES } from "@/lib/languages";
import BugReportPanel from "./BugReportPanel";
import Toast from "./Toast";

// Dynamically import Monaco Editor to avoid SSR issues
const MonacoEditor = dynamic(
  () => import("@monaco-editor/react").then((m) => m.default),
  {
    ssr: false,
    loading: () => (
      <div className="h-full flex items-center justify-center bg-slate-900/50 rounded-xl">
        <div className="flex items-center gap-3 text-slate-400">
          <Loader2 className="w-5 h-5 animate-spin" />
          <span className="text-sm">Loading editor…</span>
        </div>
      </div>
    ),
  }
);

interface ToastState {
  message: string;
  type: "error" | "success";
}

export default function BugFixer() {
  const [language, setLanguage] = useState<Language>("javascript");
  const [code, setCode] = useState<string>(DEFAULT_CODE_SAMPLES["javascript"] ?? "");
  const [isLoading, setIsLoading] = useState(false);
  const [report, setReport] = useState<BugReport | null>(null);
  const [toast, setToast] = useState<ToastState | null>(null);
  const [langDropdownOpen, setLangDropdownOpen] = useState(false);
  const [hasAnalyzed, setHasAnalyzed] = useState(false);

  const selectedLang = LANGUAGES.find((l) => l.value === language) ?? LANGUAGES[0];

  function handleLanguageSelect(lang: Language) {
    setLanguage(lang);
    setLangDropdownOpen(false);
    setReport(null);
    setHasAnalyzed(false);
    // Update editor with sample code for the new language
    setCode(DEFAULT_CODE_SAMPLES[lang] ?? "");
  }

  function handleClear() {
    setCode("");
    setReport(null);
    setHasAnalyzed(false);
  }

  function showToast(message: string, type: "error" | "success") {
    setToast({ message, type });
  }

  function dismissToast() {
    setToast(null);
  }

  const handleCheckBugs = useCallback(async () => {
    if (!code.trim()) {
      showToast("Please paste some code first!", "error");
      return;
    }

    setIsLoading(true);
    setReport(null);

    try {
      const res = await fetch("/api/check-bugs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code, language }),
      });

      const data = (await res.json()) as CheckBugsResponse;

      if (!res.ok || !data.success || !data.data) {
        showToast(data.error ?? "Analysis failed. Please try again.", "error");
        return;
      }

      setReport(data.data);
      setHasAnalyzed(true);

      if (data.data.hasBugs) {
        showToast(
          `Found ${data.data.bugs.length} bug${data.data.bugs.length !== 1 ? "s" : ""}. Check the report below.`,
          "error"
        );
      } else {
        showToast("No bugs detected! Your code looks clean. ✅", "success");
      }
    } catch {
      showToast("Network error. Please check your connection.", "error");
    } finally {
      setIsLoading(false);
    }
  }, [code, language]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* ─── Header ─── */}
      <header className="relative border-b border-slate-800/60 bg-slate-950/80 backdrop-blur-xl sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-4">
          {/* Brand */}
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-900/40">
                <Bug className="w-5 h-5 text-white" />
              </div>
              <div className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-red-500 border-2 border-slate-950 animate-pulse" />
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight text-white leading-none">
                Code Bug Fixer
              </h1>
              <p className="text-xs text-slate-500 mt-0.5">
                Instant AI proofreader for your code
              </p>
            </div>
          </div>

          {/* Right side */}
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-900 border border-slate-800 text-xs text-slate-400">
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              AI-Powered
            </div>
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-400 hover:text-white hover:border-slate-600 transition-all"
            >
              <GitBranch className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">GitHub</span>
            </a>
          </div>
        </div>
      </header>

      {/* ─── Hero strip ─── */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border-b border-slate-800/40 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-900/30 border border-emerald-800/40 text-xs text-emerald-400 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                Live Analysis
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/60 border border-slate-800/40 text-xs text-slate-400">
                <Terminal className="w-3 h-3" />
                {LANGUAGES.length} Languages
              </div>
            </div>
            <p className="text-sm text-slate-500 hidden md:block">
              Paste your code → Select language → Get instant bug analysis with exact
              line numbers & copy-ready fixes.
            </p>
          </div>
        </div>
      </div>

      {/* ─── Main workspace ─── */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 py-8">
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 h-full">
          {/* ══ LEFT PANEL: Editor ══ */}
          <div className="flex flex-col gap-4">
            {/* Panel Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-emerald-400" />
                <h2 className="text-sm font-semibold text-slate-300">Code Input</h2>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-600">
                {code.length > 0 && (
                  <span>{code.split("\n").length} lines · {code.length} chars</span>
                )}
              </div>
            </div>

            {/* Language selector */}
            <div className="relative">
              <button
                onClick={() => setLangDropdownOpen(!langDropdownOpen)}
                className="w-full flex items-center justify-between gap-3 px-4 py-3 rounded-xl bg-slate-900 border border-slate-700/60 hover:border-slate-600 text-sm font-medium transition-all cursor-pointer group"
                aria-haspopup="listbox"
                aria-expanded={langDropdownOpen}
              >
                <div className="flex items-center gap-3">
                  <span className="text-lg" role="img" aria-label={selectedLang?.label}>
                    {selectedLang?.icon}
                  </span>
                  <span className="text-slate-200">{selectedLang?.label}</span>
                  <span className="text-xs text-slate-500 font-mono px-2 py-0.5 rounded bg-slate-800 border border-slate-700/50">
                    .{selectedLang?.monacoId === "cpp" ? "cpp" : selectedLang?.monacoId}
                  </span>
                </div>
                <ChevronDown
                  className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${
                    langDropdownOpen ? "rotate-180" : ""
                  }`}
                />
              </button>

              {/* Dropdown */}
              {langDropdownOpen && (
                <>
                  <div
                    className="fixed inset-0 z-30"
                    onClick={() => setLangDropdownOpen(false)}
                  />
                  <ul
                    className="absolute top-full left-0 right-0 mt-2 z-40 rounded-xl bg-slate-900 border border-slate-700 shadow-2xl shadow-black/50 overflow-hidden"
                    role="listbox"
                  >
                    <div className="max-h-64 overflow-y-auto p-1.5 grid grid-cols-2 gap-1">
                      {LANGUAGES.map((lang) => (
                        <li key={lang.value} role="option" aria-selected={language === lang.value}>
                          <button
                            onClick={() => handleLanguageSelect(lang.value)}
                            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium transition-all cursor-pointer ${
                              language === lang.value
                                ? "bg-emerald-900/50 text-emerald-300 border border-emerald-800/50"
                                : "text-slate-300 hover:bg-slate-800 hover:text-white"
                            }`}
                          >
                            <span className="text-base">{lang.icon}</span>
                            <span>{lang.label}</span>
                            {language === lang.value && (
                              <span className="ml-auto text-emerald-400 text-xs">✓</span>
                            )}
                          </button>
                        </li>
                      ))}
                    </div>
                  </ul>
                </>
              )}
            </div>

            {/* Monaco Editor */}
            <div className="flex-1 rounded-xl overflow-hidden border border-slate-700/60 bg-slate-900 shadow-xl shadow-black/30 min-h-[400px] xl:min-h-0">
              {/* Editor chrome bar */}
              <div className="flex items-center justify-between px-4 py-2.5 bg-slate-900 border-b border-slate-700/60">
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-red-500/80 hover:bg-red-500 transition-colors" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500/80 hover:bg-yellow-500 transition-colors" />
                  <div className="w-3 h-3 rounded-full bg-emerald-500/80 hover:bg-emerald-500 transition-colors" />
                </div>
                <span className="text-xs text-slate-500 font-mono">
                  {selectedLang?.label?.toLowerCase()}.{selectedLang?.monacoId === "cpp" ? "cpp" : selectedLang?.monacoId === "html" ? "html" : selectedLang?.monacoId}
                </span>
                <div className="w-16" />
              </div>

              {/* Editor content */}
              <div className="h-[360px] xl:h-[calc(100vh-480px)] xl:min-h-[360px]">
                <MonacoEditor
                  height="100%"
                  language={selectedLang?.monacoId}
                  value={code}
                  onChange={(val) => setCode(val ?? "")}
                  theme="vs-dark"
                  options={{
                    fontSize: 14,
                    fontFamily: "'JetBrains Mono', 'Fira Code', 'Cascadia Code', monospace",
                    fontLigatures: true,
                    minimap: { enabled: false },
                    scrollBeyondLastLine: false,
                    lineNumbers: "on",
                    renderLineHighlight: "line",
                    padding: { top: 12, bottom: 12 },
                    smoothScrolling: true,
                    cursorBlinking: "smooth",
                    cursorSmoothCaretAnimation: "on",
                    bracketPairColorization: { enabled: true },
                    automaticLayout: true,
                    wordWrap: "on",
                    tabSize: 2,
                    formatOnPaste: true,
                    scrollbar: {
                      verticalScrollbarSize: 6,
                      horizontalScrollbarSize: 6,
                    },
                  }}
                />
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex items-center gap-3">
              <button
                onClick={handleCheckBugs}
                disabled={isLoading}
                className="flex-1 flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:from-slate-700 disabled:to-slate-700 disabled:cursor-not-allowed text-white font-bold text-sm shadow-lg shadow-emerald-900/30 hover:shadow-emerald-900/50 transition-all duration-200 cursor-pointer active:scale-[0.98]"
                aria-live="polite"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Scanning code…
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-white" />
                    Check for Bugs
                  </>
                )}
              </button>
              <button
                onClick={handleClear}
                disabled={isLoading}
                className="flex items-center gap-2 px-4 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed border border-slate-700/60 hover:border-slate-600 text-slate-300 hover:text-white font-semibold text-sm transition-all duration-200 cursor-pointer"
                title="Clear code"
              >
                <Trash2 className="w-4 h-4" />
                <span className="hidden sm:inline">Clear</span>
              </button>
            </div>
          </div>

          {/* ══ RIGHT PANEL: Bug Report ══ */}
          <div className="flex flex-col gap-4">
            {/* Panel Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${report?.hasBugs ? "bg-red-400" : hasAnalyzed ? "bg-emerald-400" : "bg-slate-600"}`} />
                <h2 className="text-sm font-semibold text-slate-300">Bug Report</h2>
              </div>
              {report && (
                <div className="flex items-center gap-2 text-xs">
                  {report.hasBugs ? (
                    <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-red-900/40 border border-red-800/40 text-red-400 font-semibold">
                      <Bug className="w-3 h-3" />
                      {report.bugs.length} {report.bugs.length === 1 ? "Bug" : "Bugs"} Found
                    </span>
                  ) : (
                    <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-900/40 border border-emerald-800/40 text-emerald-400 font-semibold">
                      ✅ Clean Code
                    </span>
                  )}
                </div>
              )}
            </div>

            {/* Report area */}
            <div className="flex-1 min-h-[400px] xl:min-h-0">
              {isLoading ? (
                /* Loading state */
                <div className="h-full min-h-[400px] flex flex-col items-center justify-center gap-6 rounded-2xl border border-slate-800/60 bg-slate-900/40">
                  <div className="relative">
                    <div className="w-16 h-16 rounded-full border-4 border-slate-800 border-t-emerald-500 animate-spin" />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Bug className="w-6 h-6 text-emerald-400" />
                    </div>
                  </div>
                  <div className="text-center">
                    <p className="text-base font-semibold text-slate-300 mb-1">
                      Scanning your code…
                    </p>
                    <p className="text-sm text-slate-500">
                      AI is reviewing for bugs, typos & logic errors
                    </p>
                  </div>
                  {/* Animated scan lines */}
                  <div className="flex flex-col gap-2 w-48 opacity-40">
                    {[...Array(4)].map((_, i) => (
                      <div
                        key={i}
                        className="h-1.5 bg-gradient-to-r from-emerald-900 via-emerald-600 to-transparent rounded-full animate-pulse"
                        style={{ animationDelay: `${i * 0.2}s`, width: `${85 - i * 10}%` }}
                      />
                    ))}
                  </div>
                </div>
              ) : report ? (
                /* Report panel */
                <BugReportPanel report={report} language={selectedLang?.label ?? language} />
              ) : (
                /* Empty state */
                <div className="h-full min-h-[400px] flex flex-col items-center justify-center gap-5 rounded-2xl border border-dashed border-slate-800 bg-slate-900/20 px-8 text-center">
                  <div className="w-16 h-16 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-3xl">
                    🔍
                  </div>
                  <div>
                    <h3 className="text-base font-semibold text-slate-400 mb-1">
                      No Analysis Yet
                    </h3>
                    <p className="text-sm text-slate-600 max-w-xs">
                      Paste your code in the editor, choose a language, and click{" "}
                      <span className="text-emerald-400 font-semibold">
                        &quot;Check for Bugs&quot;
                      </span>{" "}
                      to get an instant bug report.
                    </p>
                  </div>
                  <div className="flex flex-col gap-2 text-xs text-slate-600 mt-2">
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-bold text-slate-400">
                        1
                      </span>
                      <span>Paste or type your code in the editor</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-bold text-slate-400">
                        2
                      </span>
                      <span>Select your programming language</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-bold text-slate-400">
                        3
                      </span>
                      <span>Click &quot;Check for Bugs&quot; for AI analysis</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      {/* ─── Footer ─── */}
      <footer className="border-t border-slate-800/60 py-4 mt-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-wrap items-center justify-between gap-3">
          <p className="text-xs text-slate-600">
            © {new Date().getFullYear()} Code Bug Fixer — AI-Powered Code Analysis
          </p>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5 text-xs text-slate-600">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              Supports {LANGUAGES.length} languages
            </div>
            <div className="flex items-center gap-1.5 text-xs text-slate-600">
              <Sparkles className="w-3 h-3 text-emerald-500/60" />
              Powered by AI
            </div>
          </div>
        </div>
      </footer>

      {/* ─── Toast ─── */}
      {toast && (
        <Toast message={toast.message} type={toast.type} onClose={dismissToast} />
      )}
    </div>
  );
}
