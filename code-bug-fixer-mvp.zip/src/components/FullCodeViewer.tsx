"use client";

import { useState } from "react";
import { Copy, Check, Code2 } from "lucide-react";

interface FullCodeViewerProps {
  correctedCode: string;
  language: string;
}

export default function FullCodeViewer({ correctedCode, language }: FullCodeViewerProps) {
  const [copied, setCopied] = useState(false);

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(correctedCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      const el = document.createElement("textarea");
      el.value = correctedCode;
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  }

  return (
    <div className="rounded-xl border border-emerald-800/50 bg-emerald-950/20 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-3.5 bg-emerald-900/20 border-b border-emerald-800/40">
        <div className="flex items-center gap-2.5">
          <Code2 className="w-4 h-4 text-emerald-400" />
          <span className="text-sm font-semibold text-emerald-300">
            Full Corrected Code
          </span>
          <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-900/50 text-emerald-400 border border-emerald-800/50 font-mono">
            {language}
          </span>
        </div>
        <button
          onClick={handleCopy}
          className={`flex items-center gap-1.5 text-xs px-3.5 py-1.5 rounded-lg border font-medium transition-all duration-200 cursor-pointer ${
            copied
              ? "bg-emerald-900/60 border-emerald-600/60 text-emerald-300"
              : "bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700 hover:text-white"
          }`}
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5" />
              Copied!
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              Copy All
            </>
          )}
        </button>
      </div>

      {/* Code content */}
      <div className="relative">
        {/* Line numbers + code */}
        <div className="overflow-auto max-h-96">
          <table className="w-full border-collapse text-sm font-mono">
            <tbody>
              {correctedCode.split("\n").map((line, i) => (
                <tr key={i} className="hover:bg-white/[0.03] transition-colors">
                  <td className="select-none text-right pr-4 pl-4 py-0.5 text-slate-600 text-xs w-10 shrink-0 border-r border-slate-800/50">
                    {i + 1}
                  </td>
                  <td className="pl-4 pr-4 py-0.5 text-slate-300 whitespace-pre">
                    {line || " "}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
