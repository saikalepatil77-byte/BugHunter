"use client";

import { useState } from "react";
import { CheckCircle2, Bug, LayoutList, Code2, AlertTriangle } from "lucide-react";
import type { BugReport } from "@/types/bug-report";
import BugCard from "./BugCard";
import FullCodeViewer from "./FullCodeViewer";

interface BugReportPanelProps {
  report: BugReport;
  language: string;
}

type ActiveTab = "bugs" | "fixed-code";

export default function BugReportPanel({ report, language }: BugReportPanelProps) {
  const [activeTab, setActiveTab] = useState<ActiveTab>("bugs");

  if (!report.hasBugs) {
    return (
      <div className="h-full flex flex-col gap-6">
        {/* Clean Code celebration */}
        <div className="flex-1 flex flex-col items-center justify-center gap-5 text-center py-12 rounded-2xl border border-emerald-800/40 bg-emerald-950/20">
          <div className="w-20 h-20 rounded-full bg-emerald-900/40 border border-emerald-700/50 flex items-center justify-center text-4xl">
            ✅
          </div>
          <div>
            <h3 className="text-2xl font-bold text-emerald-400 mb-2">
              No Bugs Detected!
            </h3>
            <p className="text-slate-400 text-sm max-w-xs">
              Your code looks clean and well-written. Great work!
            </p>
          </div>
          <div className="px-5 py-3 rounded-xl bg-slate-900/60 border border-slate-700/50 max-w-sm">
            <p className="text-sm text-slate-300 italic">&ldquo;{report.summary}&rdquo;</p>
          </div>
        </div>

        {/* Show full code anyway */}
        <FullCodeViewer correctedCode={report.correctedFullCode} language={language} />
      </div>
    );
  }

  const bugCount = report.bugs.length;

  return (
    <div className="flex flex-col gap-5 h-full">
      {/* Summary card */}
      <div className="flex items-start gap-3 px-5 py-4 rounded-xl bg-slate-900/60 border border-slate-700/50">
        <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div>
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-widest mb-1">
            Analysis Summary
          </p>
          <p className="text-sm text-slate-300">{report.summary}</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-900/60 border border-slate-700/50">
        <button
          onClick={() => setActiveTab("bugs")}
          className={`flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold transition-all duration-200 cursor-pointer ${
            activeTab === "bugs"
              ? "bg-slate-700 text-white shadow-sm"
              : "text-slate-400 hover:text-slate-200"
          }`}
        >
          <LayoutList className="w-4 h-4" />
          <span>Bug List</span>
          <span
            className={`text-xs px-2 py-0.5 rounded-full font-bold ${
              activeTab === "bugs"
                ? "bg-red-900/70 text-red-300"
                : "bg-slate-800 text-slate-400"
            }`}
          >
            {bugCount}
          </span>
        </button>
        <button
          onClick={() => setActiveTab("fixed-code")}
          className={`flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold transition-all duration-200 cursor-pointer ${
            activeTab === "fixed-code"
              ? "bg-slate-700 text-white shadow-sm"
              : "text-slate-400 hover:text-slate-200"
          }`}
        >
          <Code2 className="w-4 h-4" />
          <span>Fixed Code</span>
          {activeTab === "fixed-code" && (
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
          )}
        </button>
      </div>

      {/* Tab content */}
      {activeTab === "bugs" ? (
        <div className="flex flex-col gap-3 overflow-y-auto">
          {report.bugs.length === 0 ? (
            <div className="text-center py-10 text-slate-500 text-sm">
              No specific bugs listed in the report.
            </div>
          ) : (
            report.bugs.map((bug, index) => (
              <BugCard key={index} bug={bug} index={index} />
            ))
          )}
        </div>
      ) : (
        <FullCodeViewer correctedCode={report.correctedFullCode} language={language} />
      )}

      {/* Bug count footer */}
      {activeTab === "bugs" && bugCount > 0 && (
        <div className="flex items-center justify-between pt-2 border-t border-slate-800/60">
          <div className="flex items-center gap-2 text-sm text-slate-500">
            <Bug className="w-4 h-4" />
            <span>
              {bugCount} {bugCount === 1 ? "bug" : "bugs"} found
            </span>
          </div>
          <button
            onClick={() => setActiveTab("fixed-code")}
            className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold underline underline-offset-2 cursor-pointer transition-colors"
          >
            View all fixes →
          </button>
        </div>
      )}
    </div>
  );
}
