export type ErrorType = "Syntax" | "Missing Definition" | "Crash Risk" | "Logic";

export interface Bug {
  line: number | string;
  errorType: ErrorType;
  explanation: string;
  suggestedFix: string;
}

export interface BugReport {
  hasBugs: boolean;
  summary: string;
  bugs: Bug[];
  correctedFullCode: string;
}

export interface CheckBugsRequest {
  code: string;
  language: string;
}

export interface CheckBugsResponse {
  success: boolean;
  data?: BugReport;
  error?: string;
}

export type Language =
  | "python"
  | "javascript"
  | "typescript"
  | "java"
  | "cpp"
  | "html"
  | "css"
  | "rust"
  | "go"
  | "php";

export interface LanguageOption {
  value: Language;
  label: string;
  monacoId: string;
  icon: string;
}
