import BugFixer from "@/components/BugFixer";

export default function Home() {
  return <BugFixer />;
}
