import { NextRequest, NextResponse } from "next/server";
import type { CheckBugsRequest, CheckBugsResponse, BugReport } from "@/types/bug-report";

const SYSTEM_PROMPT = `You are an expert code analysis AI. Your job is to analyze the provided code for bugs, errors, and issues.

You MUST respond with ONLY a valid JSON object — no markdown, no code fences, no explanation text — following this EXACT schema:

{
  "hasBugs": boolean,
  "summary": "Short 1-sentence overview of the code quality",
  "bugs": [
    {
      "line": number or "Line X-Y" string for ranges,
      "errorType": "Syntax" | "Missing Definition" | "Crash Risk" | "Logic",
      "explanation": "Simple, beginner-friendly explanation of why this is a bug",
      "suggestedFix": "Exact corrected line(s) of code ready to replace the broken line"
    }
  ],
  "correctedFullCode": "The complete, fully fixed version of the user's code"
}

Rules:
- If no bugs are found, set hasBugs to false, bugs to [], and correctedFullCode to the original code.
- Always include ALL bugs found, not just the first one.
- Explanations must be plain English, suitable for beginners.
- suggestedFix must be exact, copy-ready code — not pseudo-code.
- The correctedFullCode must be the complete file with ALL bugs fixed.
- line can be a number (e.g., 4) or a string range (e.g., "Line 4-5").
- NEVER include markdown formatting in your JSON response.
- NEVER wrap the JSON in code fences or backticks.`;

function getMockResponse(language: string): BugReport {
  const examples: Record<string, BugReport> = {
    python: {
      hasBugs: true,
      summary: "Found 3 bugs including an undefined variable, a syntax error, and a type error.",
      bugs: [
        {
          line: 2,
          errorType: "Missing Definition",
          explanation: "The variable `mesage` is used here but it was never defined. It looks like a typo — you probably meant `message`.",
          suggestedFix: "message = 'Hello, World!'"
        },
        {
          line: 5,
          errorType: "Syntax",
          explanation: "The `print` statement is missing its closing parenthesis. Python 3 requires `print()` to be called as a function.",
          suggestedFix: "print(message)"
        },
        {
          line: 8,
          errorType: "Logic",
          explanation: "You're trying to add a string and a number directly. This will raise a TypeError at runtime. Convert the number to a string first.",
          suggestedFix: "result = message + str(count)"
        }
      ],
      correctedFullCode: "# Fixed Python script\nmessage = 'Hello, World!'\ncount = 3\n\nprint(message)\n\nfor i in range(count):\n    result = message + str(count)\n    print(result)"
    },
    javascript: {
      hasBugs: true,
      summary: "Found 2 bugs: an undeclared variable reference and a missing return statement.",
      bugs: [
        {
          line: 3,
          errorType: "Missing Definition",
          explanation: "The variable `usrName` is referenced here but was never declared. You likely meant `userName` (check for the typo).",
          suggestedFix: "const userName = 'Alice';"
        },
        {
          line: 9,
          errorType: "Logic",
          explanation: "The function `getGreeting` is missing a `return` statement. Without it, the function always returns `undefined` instead of the greeting string.",
          suggestedFix: "return `Hello, ${userName}!`;"
        }
      ],
      correctedFullCode: "// Fixed JavaScript\nconst userName = 'Alice';\n\nfunction getGreeting(name) {\n  const greeting = `Hello, ${name}!`;\n  return greeting;\n}\n\nconsole.log(getGreeting(userName));"
    },
    default: {
      hasBugs: true,
      summary: "Found 2 issues in the code: a syntax error and a potential crash risk.",
      bugs: [
        {
          line: 1,
          errorType: "Syntax",
          explanation: "There appears to be a syntax error at the start of the file. Check for missing brackets, parentheses, or incorrect keywords.",
          suggestedFix: "// Ensure your code starts with a valid statement or declaration."
        },
        {
          line: "Line 5-7",
          errorType: "Crash Risk",
          explanation: "This section accesses a property without null-checking first. If the object is null or undefined, this will crash the program.",
          suggestedFix: "// Add a null check: if (obj !== null && obj !== undefined) { ... }"
        }
      ],
      correctedFullCode: "// Your corrected code would appear here with all fixes applied."
    }
  };

  return examples[language] ?? examples.default;
}

async function analyzeWithOpenAI(code: string, language: string): Promise<BugReport> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    throw new Error("OPENAI_API_KEY not configured");
  }

  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "gpt-4o-mini",
      temperature: 0.1,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        {
          role: "user",
          content: `Analyze this ${language} code for bugs:\n\n\`\`\`${language}\n${code}\n\`\`\``,
        },
      ],
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`OpenAI API error ${response.status}: ${errText}`);
  }

  const json = await response.json() as {
    choices: Array<{ message: { content: string } }>;
  };

  const content = json.choices[0]?.message?.content;
  if (!content) throw new Error("Empty response from OpenAI");

  const parsed = JSON.parse(content) as BugReport;
  return parsed;
}

async function analyzeWithGroq(code: string, language: string): Promise<BugReport> {
  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey) {
    throw new Error("GROQ_API_KEY not configured");
  }

  const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "llama-3.3-70b-versatile",
      temperature: 0.1,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        {
          role: "user",
          content: `Analyze this ${language} code for bugs:\n\n\`\`\`${language}\n${code}\n\`\`\``,
        },
      ],
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Groq API error ${response.status}: ${errText}`);
  }

  const json = await response.json() as {
    choices: Array<{ message: { content: string } }>;
  };

  const content = json.choices[0]?.message?.content;
  if (!content) throw new Error("Empty response from Groq");

  const parsed = JSON.parse(content) as BugReport;
  return parsed;
}

export async function POST(req: NextRequest): Promise<NextResponse<CheckBugsResponse>> {
  try {
    const body = await req.json() as CheckBugsRequest;
    const { code, language } = body;

    if (!code || typeof code !== "string" || code.trim().length === 0) {
      return NextResponse.json(
        { success: false, error: "No code provided." },
        { status: 400 }
      );
    }

    if (!language || typeof language !== "string") {
      return NextResponse.json(
        { success: false, error: "No language specified." },
        { status: 400 }
      );
    }

    // Limit code size to prevent abuse
    if (code.length > 20000) {
      return NextResponse.json(
        { success: false, error: "Code exceeds the 20,000 character limit." },
        { status: 400 }
      );
    }

    let report: BugReport;

    // Try OpenAI first, then Groq, then fall back to mock
    if (process.env.OPENAI_API_KEY) {
      try {
        report = await analyzeWithOpenAI(code, language);
      } catch (openaiErr) {
        console.error("OpenAI failed, trying Groq:", openaiErr);
        if (process.env.GROQ_API_KEY) {
          try {
            report = await analyzeWithGroq(code, language);
          } catch (groqErr) {
            console.error("Groq failed, using mock:", groqErr);
            report = getMockResponse(language);
          }
        } else {
          report = getMockResponse(language);
        }
      }
    } else if (process.env.GROQ_API_KEY) {
      try {
        report = await analyzeWithGroq(code, language);
      } catch (groqErr) {
        console.error("Groq failed, using mock:", groqErr);
        report = getMockResponse(language);
      }
    } else {
      // No API keys — use mock response
      console.warn("No AI API keys configured. Using mock response.");
      report = getMockResponse(language);
    }

    return NextResponse.json({ success: true, data: report });
  } catch (err) {
    console.error("check-bugs route error:", err);
    return NextResponse.json(
      { success: false, error: "Internal server error. Please try again." },
      { status: 500 }
    );
  }
}
