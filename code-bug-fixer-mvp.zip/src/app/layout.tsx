import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "🐞 Code Bug Fixer — Instant AI Code Analysis",
  description:
    "Paste broken code, select your language, and instantly receive a human-friendly bug report with exact line numbers, explanations, and copy-ready fixes.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-slate-950 text-slate-100 antialiased">{children}</body>
    </html>
  );
}
